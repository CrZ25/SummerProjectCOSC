import processing.core.*;
import java.util.*;

public class Weapon extends main {
	float xPos, yPos, xWidthB, yHeightB;
	boolean mousePressed;
	boolean posLock;
	float mouseX, mouseY;
	PApplet pApplet;

	public Weapon(float xPos, float yPos, float xWidthB, float yHeightB) {
		this.xPos = xPos;
		this.yPos = yPos;
		this.xWidthB = xWidthB;
		this.yHeightB = yHeightB;
		this.mousePressed = false;
	}

	public void setPos() {
		this.xPos = mouseX;
		this.yPos = mouseY;
		if (this.xPos - 24 <= 0) {
			this.xPos = 24;
		}
		if (this.yPos - 24 <= 0) {
			this.yPos = 24;
		}
		if (this.xPos + 24 >= 640) {
			this.xPos = 640 - 24;
		}
		if (this.yPos + 24 >= 512) {
			this.yPos = 512 - 24;
		}
	}

	public void availiableSpot() {
		if (this.xPos - 24 <= 0) {
		} else if (this.yPos - 24 <= 0) {
		} else if (this.xPos + 24 >= 640) {
		} else if (this.yPos + 24 >= 512) {
		}
	}

	public void update(float mouseX, float mouseY, boolean mousePressed) {
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		this.mousePressed = mousePressed;
		if (mouseOver()) {
			setPos();
		}
	}

	public ImageData display() {
		return new ImageData(0, xPos, yPos);
	}

	public boolean mouseOver() {
		if (mousePressed && mouseX >= (xPos - xWidthB / 2) && mouseX <= (xPos + xWidthB / 2)
				&& mouseY >= (yPos - yHeightB / 2) && mouseY <= (yPos + yHeightB / 2)) {
			return true;
		}
		return false;
	}
}