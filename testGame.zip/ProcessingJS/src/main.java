import processing.core.*;
import java.util.*;

public class main extends PApplet {
	PImage weapon0;
	ArrayList<Weapon> w = new ArrayList<Weapon>();
	ArrayList<Weapon> reverseW = new ArrayList<Weapon>();
	final int AX = 20, AY = 16;
	int[][] array = new int[AX][AY];
	PImage[] weapons = new PImage[4];

	// image to be sent back to main display for
	ImageData iTmp = new ImageData(0, 0, 0);

	public void settings() {
		// width : 128px for the weapons menu
		// width : 640px for actual map
		// height : 512px (64 * 8)
		size(768, 512);
	}

	public void setup() {
		arrayInit();

		frameRate(200);
		smooth();
		textAlign(CENTER);
		imageMode(CENTER);
		rectMode(CENTER);
		textSize(32);
		noFill();
		stroke(255);

		// Load in Weapons
		for (int i = 0; i < weapons.length; i++) {
			weapons[i] = loadImage("weap" + i + ".png");
		}

		// adding 5 Weapons for testing purposes
		for (int i = 1; i < 5; i++) {
			w.add(new Weapon(i * 80, i * 80, 64, 64));
		}
	}

	public static void main(String[] args) {
		PApplet.main("main");
	}

	public void draw() {
		background(0);

		drawMap();
		weaponDisplay();
	}

	public void arrayInit() {
		// set up a array
		for (int i = 0; i < AY; i++) {
			for (int j = 0; j < AX; j++) {
				array[j][i] = 0;
			}
		}
		for (int i = 0; i < AX; i++) {
			array[i][0] = 3;
		}
		for (int i = 0; i < AX; i++) {
			array[i][AY - 1] = 3;
		}
	}

	public void drawMap() {
		for (int row = 0; row < array.length; row++) {
			for (int col = 0; col < array[row].length; col++) {
				if (array[row][col] == 0) {
					noFill();
					rect(row * 32 + 16, col * 32 + 16, 32, 32);
				}
				if (array[row][col] == 3) {
					fill(200, 200, 200);
					rect(row * 32 + 16, col * 32 + 16, 32, 32);
				}
			}
		}
	}

	public void weaponDisplay() {
		checkWeaponPlace();
		// int i is for debugging purposes
		int i = 0;
		
		for (Weapon tmp : w) {
			// update function
			tmp.update(mouseX, mouseY, mousePressed);

			// display from iTmp
			iTmp = tmp.display();
			image(weapons[iTmp.getImg()], iTmp.getX(), iTmp.getY());
			// text is for debugging purposes
			text(i, iTmp.getX(), iTmp.getY() + 12);
			i++;
		}
	}

	public void checkWeaponPlace() {
		// Adding the Weapons arraylist and reversing it
		reverseW.addAll(w);
		Collections.reverse(reverseW);
		int i = -1;
		
		
		// Collisions with (n*n-1)/2 efficiency
		for (Weapon weaponsForward : w) {
			reverseW.remove(reverseW.size() - 1);
			i++;
			for (Weapon weaponsReverse : reverseW) {
				if (w.get(i).xPos - 24 < weaponsReverse.xPos + 24 && w.get(i).xPos + 24 > weaponsReverse.xPos - 24
						&& w.get(i).yPos - 24 < weaponsReverse.yPos + 24
						&& w.get(i).yPos + 24 > weaponsReverse.yPos - 24) {
					// below weapon towers
					if (w.get(i).yPos - 24 < weaponsReverse.yPos + 24) {
						System.out.println("3");
						w.get(i).yPos = weaponsReverse.yPos - 48;
					}
					// top of weapon towers
					if (w.get(i).yPos + 24 > weaponsReverse.yPos - 24) {
						System.out.println("4");
						w.get(i).yPos = weaponsReverse.yPos + 48;
					}
					// right of weapon towers
					if (w.get(i).xPos - 24 < weaponsReverse.xPos + 24) {
						System.out.println("1");
						w.get(i).xPos = weaponsReverse.xPos - 48;
					}
					// left of weapon towers
					if (w.get(i).xPos + 24 > weaponsReverse.xPos - 24) {
						System.out.println("2");
						w.get(i).xPos = weaponsReverse.xPos + 48;
					}
				}
			}
		}
	}
}
